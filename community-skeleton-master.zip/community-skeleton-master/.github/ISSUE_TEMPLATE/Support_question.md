---
name: ⛔ Support Question
about: Visit https://support.uvdesk.com/ to learn more about how the uvdesk team can assist you

---

We use GitHub issues only to discuss about uvdesk bugs and new features. For customizations and extended support:

- Contact us at support@uvdesk.com
- Visit official support website (https://support.uvdesk.com/en/)
- Visit our community forums (https://forums.uvdesk.com)

Thanks!
