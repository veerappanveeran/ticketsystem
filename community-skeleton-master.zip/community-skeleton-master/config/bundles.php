<?php

return [
    Webkul\UVDesk\CoreFrameworkBundle\UVDeskCoreFrameworkBundle::class => ['all' => true],
    Webkul\UVDesk\AutomationBundle\UVDeskAutomationBundle::class => ['all' => true],
    Webkul\UVDesk\ExtensionFrameworkBundle\UVDeskExtensionFrameworkBundle::class => ['all' => true],
    Webkul\UVDesk\MailboxBundle\UVDeskMailboxBundle::class => ['all' => true],
    Webkul\UVDesk\SupportCenterBundle\UVDeskSupportCenterBundle::class => ['all' => true],
    Webkul\UVDesk\ApiBundle\UVDeskApiBundle::class => ['all' => true],
];
